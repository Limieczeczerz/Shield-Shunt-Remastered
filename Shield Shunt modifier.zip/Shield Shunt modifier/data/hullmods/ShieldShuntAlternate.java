package data.hullmods;

import java.awt.Color;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ShieldShuntAlternate extends BaseHullMod {

	//public static float EMP_RESISTANCE = 50f;
	//public static float VENT_RATE_BONUS = 50f;
	public static float FIRERATE_BONUS = 20f;


	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getBallisticRoFMult().modifyMult(id, 1f + FIRERATE_BONUS * 0.01f);
		stats.getEnergyRoFMult().modifyMult(id, 1f + FIRERATE_BONUS * 0.01f);
	}

	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		ship.setShield(ShieldType.NONE, 0f, 1f, 1f);
	}
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) FIRERATE_BONUS + "%";
		return null;
	}

	public boolean isApplicableToShip(ShipAPI ship) {
		if (ship.getVariant().getHullSpec().getShieldType() == ShieldType.NONE && 
				!ship.getVariant().hasHullMod("frontshield")) return false;
		if (ship.getVariant().hasHullMod(HullMods.SHIELD_SHUNT)) return true;
		if (ship.getVariant().hasHullMod(HullMods.MAKESHIFT_GENERATOR)) return false;
		return ship != null && ship.getShield() != null;
	}
	
	public String getUnapplicableReason(ShipAPI ship) {
		if (ship.getVariant().hasHullMod(HullMods.MAKESHIFT_GENERATOR)) {
			return "Incompatible with Makeshift Shield Generator";
		}
		return "Ship has no shields";
	}
	
	@Override
	public boolean shouldAddDescriptionToTooltip(HullSize hullSize, ShipAPI ship, boolean isForModSpec) {
		return false;
	}

	@Override
	public void addPostDescriptionSection(TooltipMakerAPI tooltip, HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
		float pad = 3f;
		float opad = 10f;
		Color h = Misc.getHighlightColor();

		tooltip.addPara("A tone-deaf addition to Domain's military technology.", opad);
		tooltip.addPara("Shield projectors and general flux infrastructure are removed and replaced with a quasi-technologically advanced " +
				"accelerated ammo and energy battery feed.", opad);
		tooltip.addPara("Ship's shields are removed. Firerate is increased by %s.", opad, h,
				"" + (int)FIRERATE_BONUS + "%");
		tooltip.addPara("Often utilized by more disturbed officers and engineers." +
						"Unfortunately seen more often during the AI Wars due to Hegemony command neglecting the mental health of traumatized military personnel.", opad);

	}
}








